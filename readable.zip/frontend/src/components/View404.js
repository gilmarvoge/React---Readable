import React, { Component } from 'react';
import notFound from '../notFound.png'

class View404NotFound extends Component {
    render() {
        return (
            <div>   
            <img  src={notFound}    ></img>
            </div>
        )
    }
}
export default View404NotFound

